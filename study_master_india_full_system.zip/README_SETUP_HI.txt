STUDY MASTER INDIA — Full Starter (Login + Student Dashboard + Admin Panel + Security)

WHAT IS INCLUDED
- Email/password signup, login and password-reset email.
- Student profile (name/class), private online notes (create/edit/delete).
- Public-to-signed-in-students learning resources.
- Admin panel to publish/unpublish/delete resources and view basic student profile information.
- Firestore security rules: each student can access only their own notes; admin rights are provisioned manually.
- No feature lets an admin view student passwords. Firebase Authentication does not expose users' plain-text passwords.

IMPORTANT: NOT LIVE OR CONFIGURED YET
This ZIP is source code. You must configure Firebase and host it. Do not announce it as live until you test all security rules.

SETUP FROM ANDROID
1. Ask a parent/guardian to help with the Google/Firebase account and privacy setup.
2. Go to https://console.firebase.google.com/ and create a Firebase project.
3. Add a Web app in Project settings. Copy the firebaseConfig values.
4. Open index.html in a text/code editor and replace all PASTE... placeholders in firebaseConfig with the real values.
5. Firebase Console > Authentication > Get started > Sign-in method > enable Email/Password.
6. Firebase Console > Firestore Database > Create database.
7. Firestore > Rules: paste the full contents of firestore.rules and click Publish.
8. Create the first admin account through the website's Sign Up screen.
9. In Firestore Data, manually create a collection named `admins`. Add a document whose document ID is the first admin user's Firebase Authentication UID. The document fields must be:
   active (boolean) = true
   Do NOT create this admin document through the public website. Only an owner with Firebase Console access should do this.
   To find the UID: Firebase Console > Authentication > Users > copy the UID of your account.
10. Host index.html on a static host (e.g. Netlify). Upload index.html as the main page. You may keep firestore.rules and README for your records; do not expose secret admin credentials.
11. Test using two different student accounts: confirm each can see only their own notes. Confirm a normal student cannot see Admin Panel or publish content. Test the Firestore rules in Rules Playground before inviting students.

SECURITY NOTES
- Never use open rules such as `allow read, write: if true;`.
- Never put service-account JSON, private keys or admin credentials in frontend HTML.
- Firebase web config is designed to be included in the client; access is controlled by Authentication and Firestore Rules.
- The admin panel displays basic student profile details to the admin. Collect only necessary information and provide a privacy notice.
- For a public student service, plan account deletion, backups, abuse reporting, content moderation, privacy policy, and applicable Indian child-data/privacy requirements before launch.
- This starter does not yet implement account deletion, email verification enforcement, moderation/reporting, paid plans, analytics, or production monitoring.
- Profile deletion is intentionally disabled in the rules; handle account deletion through a verified admin/support process or a trusted backend, not by allowing public users to delete arbitrary data.
- Hosting providers and Firebase quotas/pricing may change. Review the current plans before launch.

TROUBLESHOOTING
- Setup pending: config placeholders not replaced.
- auth/operation-not-allowed: enable Email/Password provider.
- permission-denied: check Firestore Rules and ensure admin doc exists only for the trusted owner UID.
- Admin tab missing: check the correct UID document exists in `admins` with `active: true`.
- Avoid using real student data while testing.
